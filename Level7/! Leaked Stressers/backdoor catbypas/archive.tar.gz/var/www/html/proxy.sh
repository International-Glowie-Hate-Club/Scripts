sh flayget.sh
